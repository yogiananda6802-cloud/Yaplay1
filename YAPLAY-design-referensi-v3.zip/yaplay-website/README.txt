YAPLAY — desain frontend demo
- Buka index.html di browser untuk melihat desain.
- Tampilan terinspirasi dari referensi: header gelap, aksen merah menyala, grid kategori, kolom pencarian, kartu game, dan navigasi bawah.
- Konten diadaptasi untuk toko top-up game yang sah, bukan situs taruhan/kasino.
- Belum ada backend, akun, pembayaran, API supplier, atau pengiriman top-up otomatis.
- Semua harga dan alur transaksi harus dihubungkan dan diuji sebelum dipakai publik.
